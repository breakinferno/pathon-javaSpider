# -*- encoding:utf-8 -*-

import time, sys, classify

reload(sys)
sys.setdefaultencoding("utf-8")

keyword = '人寿'
classify.calssify(keyword).run()