# -*- coding: utf-8 -*-

# 缓存配置
cache_dir = 'cache'
cache_session_name = 'requests_wechatsogou_session'