
import getlevel, os, classify

#os.system("python E:\\Internship\\pythonSpiders\\version2.0\\getlevel.py")
#getlevel.fenlei().run()
classify.calssify().run()
